package com.skd.app;

public class A1 {

	
	public String m1()
	{
		return "A1 - m1 --> "+m2();
	}
	
	public String m2()
	{
		return "A1 - m2 --> "+m3();
	}
	
	public String m3()
	{
		return "A1 - m3 --> "+m4();
	}
	
	public String m4()
	{
		return "A1 - m4 --> "+m5();
	}
	
	public String m5()
	{
		return "A1 - m5 --> "+m6();
	}
	
	public String m6()
	{
		return "A1 - m6  Fin";
	}
	
	
}
